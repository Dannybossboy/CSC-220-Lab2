public class SavingsAccount extends BankAccount {
       /* File: SavingsAccount.java
 * By: Daniel Smirnoff
 * Date: 9/15/2023
 * Compile:
 * Usage:
 * System: I think every system
 * Description: BankAccount  SubClass
 */
    public SavingsAccount(int balance) { //Constructor
        super("", "", balance, "Savings");
    }

}
