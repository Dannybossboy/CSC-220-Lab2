public class CheckingsAccount extends BankAccount{
       /* File: CheckingsAccount.java
 * By: Daniel Smirnoff
 * Date: 9/15/2023
 * Compile:
 * Usage:
 * System: I think every system
 * Description: BankAccount  SubClass
 */
    public CheckingsAccount(int balance) { //Constructor
        super("", "", balance, "Checkings");
    }
}
